<!DOCTYPE html>
<html>
<head>
	<title>slide</title>
</head>
<body>
          <div class="container-fluid">
          <div class="row">
            
  <!-- Wrapper for slides -->
<div id="myCarousel" class="carousel slide" data-ride="carousel"> 
<div class="carousel-inner">
       <div class="item active">
           <img src="images/s1.jpg" class="img-responsive">
            	<div class="carousel-caption">
                <h3>POUTRY</h3>
            </div>    
        </div>
        <div class="item">
            <img src="images/s2.jpg" alt="" class="img-responsive">
            	<div class="carousel-caption">
                <h3>TOBACCO</h3>
            </div>
        </div>
       
        <div class="item">
            <img src="images/s3.jpg" class="img-responsive">
            <div class="carousel-caption">
                <h3">HOTCULTURE</h3>
            </div>
        </div>
         <div class="item">
            <img src="images/gmb.jpg" class="img-responsive">
            	<div class="carousel-caption">
                <h3>Grain Marketing Board</h3>
            </div>
        </div>

</div>
</div>
         </div>
         </div>


	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	 <link rel="stylesheet" href="css/normalize.css">
 <meta name="viewport" content="width=device-width, initial-scale=1"> 
<link href="css/bootstrap.css" type="text/css"rel="stylesheet" />
<link href="css/bootstrap.min.css" type="text/css"rel="stylesheet" />
 <link href="css/bootstrap-theme.css" type="text/css"rel="stylesheet" />
 <link href="css/bootstrap-theme.min.css" type="text/css"rel="stylesheet" />
 <script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
 <script type="text/javascript" src="js/jquery.js"></script>
</body>
</html>














