# muzindahub_zimfarmers
an online system to support farmers,agric_helpers and suppliers/buyers
